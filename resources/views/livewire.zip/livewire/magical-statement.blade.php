<div class="magical-box-wrapper">
    <div class="login_wrapper"
        style=" background-image: url(https://santa.3dhdesign.com/assets/images/magical%20background.jpg); background-position-y: center;">
        <div class="magical-wrapper">
            <div class="form-heading magical-text">Magical Statement</div>
            <div class="magical-content" id="typedtext">{{ $content }}</div>
            <p class="form-bottom-link" style="color: red; margin-top: 26px;">Merry Christmas from 3DH Family</i>
        </div>
    </div>
    <div class="close-button" id="close-btn" wire:click.prevent="closeMagical">
        <i class="fa-regular fa-circle-xmark"></i>
    </div>

</div>
